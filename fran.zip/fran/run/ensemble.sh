#!/bin/bash
python -m ipdb ensemble_singlegpu.py  -t lits -e LITS-499 LITS-500 LITS-501 LITS-502 LITS-503 -i /s/insync/datasets/crc_project/images_ub/done 
