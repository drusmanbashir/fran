#!/bin/bash
python ensemble.py  -t litsmc -e LITS-787 LITS-810 LITS-811 -i /s/xnat_shadow/crc/wxh/images/

    # args.overwrite=False
    # args.t= 'litsmc'
    # args.input_folder ="/s/xnat_shadow/crc/srn/cases_with_findings/images"
    # args.ensemble= ["LITS-787", "LITS-810", "LITS-811"]
# python ensemble.py  -t lits  -e LITS-499 LITS-500 LITS-501 LITS-502 LITS-503 -i /s/xnat_shadow/litq/test/images_few/ -o
