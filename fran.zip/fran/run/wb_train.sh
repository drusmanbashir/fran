#!/bin/bash
python train.py -t lits32 -d 2 --bs 8 -f 2
