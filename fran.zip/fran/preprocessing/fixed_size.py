# %%
from monai.transforms import Compose, MapTransform
from monai.transforms.io.dictionary import SaveImaged
from monai.transforms.spatial.dictionary import Resized
from monai.transforms.utility.dictionary import (
    DeleteItemsd,
    EnsureChannelFirstd,
    EnsureTyped,
    SqueezeDimd,
)
import torch
from fastcore.all import Union, store_attr
from fastcore.foundation import GetAttr
from fran.data.dataset import MaskLabelRemapd
from fran.preprocessing.datasetanalyzers import bboxes_function_version
from fran.preprocessing.patch import PatchDataGenerator, PatchGenerator
from fran.transforms.imageio import LoadTorchd, TorchWriter
from fran.transforms.misc_transforms import FgBgToIndicesd2
from fran.utils.string import info_from_filename
from pathlib import Path
import SimpleITK as sitk
from fastcore.basics import GetAttr, store_attr

from fran.utils.fileio import *
from fran.utils.helpers import *
from fran.utils.imageviewers import *
from label_analysis.totalseg import TotalSegmenterLabels
import torch
from fran.utils.dictopts import DictToAttr
import torchio as tio
from fran.transforms.spatialtransforms import PadDeficitImgMask
from fran.utils.fileio import load_dict, maybe_makedirs, save_dict
from fran.utils.helpers import multiprocess_multiarg
from fran.utils.string import info_from_filename, strip_extension

from pathlib import Path

import ipdb
import numpy as np
import SimpleITK as sitk
from fastcore.basics import GetAttr, store_attr

import ipdb

tr = ipdb.set_trace

from fran.preprocessing.datasetanalyzers import bboxes_function_version
from fran.preprocessing.fixed_spacing import _Preprocessor


@ray.remote(num_cpus=1)
class FixedSizeMaker(object):
    def __init__(self):
        pass

    def process(
        self,
        dicis,
        spatial_size,
        output_folder_im,
        output_folder_lm,
        src_dest_labels=None,
    ):

        L = LoadTorchd(keys=["lm", "image"])
        M = MaskLabelRemapd(keys=["lm"], src_dest_labels=src_dest_labels, use_sitk=True)
        E = EnsureChannelFirstd(keys=["image", "lm"], channel_dim="no_channel")
        Rz = Resized(
            keys=["image", "lm"], spatial_size=spatial_size, mode=["linear", "nearest"]
        )
        S = SqueezeDimd(keys=["image", "lm"])

        Si = SaveImaged(
            keys=["image"],
            output_ext="pt",
            writer=TorchWriter,
            output_dir=output_folder_im,
            output_postfix="",
            output_dtype="float32",
            separate_folder=False,
        )
        Sl = SaveImaged(
            output_ext="pt",
            keys=["lm"],
            writer=TorchWriter,
            output_dtype="uint8",
            output_dir=output_folder_lm,
            output_postfix="",
            separate_folder=False,
        )
        Del = DeleteItemsd(keys=["image", "lm"])

        # S1 = SaveImage(output_ext='pt',  output_dir=self.output_fldr_imgs, output_postfix=str(1), output_dtype='float32', writer=TorchWriter,separate_folder=False)
        if src_dest_labels:
            tfms = Compose([L, M, E, Rz, S, Si, Sl, Del])
        else:
            tfms = Compose([L, E, Rz, S, Si, Sl, Del])
        for dici in dicis:
            try:
                dici = tfms(dici)
            except Exception as e:
                print(e)

        return 1


# %%
class FixedSizeDataGenerator(PatchDataGenerator):
    _default = "project"

    def __init__(
        self, project, data_folder, spatial_size, src_dest_labels=None
    ) -> None:
        if isinstance(spatial_size, int):
            spatial_size = [spatial_size] * 3
        store_attr()

    def setup(self, overwrite=False):
        self.prepare_dicts()
        super().setup(overwrite=overwrite)

    def prepare_dicts(self):
        images_fldr = self.data_folder / ("images")
        lms_fldr = self.data_folder / ("lms")

        lms = list(lms_fldr.glob("*"))
        imgs = list(images_fldr.glob("*"))

        self.dicis = []
        for img in imgs:
            case_id_info = info_from_filename(img.name, full_caseid=True)
            case_id = case_id_info["case_id"]
            lm_value = find_matching_fn(img, lms, False)

            # Create the dictionary for the current image
            dic = {"case_id": case_id, "image": img, "lm": lm_value}

            # Append the dictionary to the dicis list
            self.dicis.append(dic)
        # self.dicis= [{"case_id": info_from_filename(img.name, full_caseid=True)['case_id'], "image": img , "lm": find_matching_fn(img,lms,False)} for img in imgs]

    def remove_completed_cases(self):
        dicis_out = []
        for dici in self.dicis:
            if dici["case_id"] not in self.existing_case_ids:
                dicis_out.append(dici)
        self.dicis = dicis_out
        print("Remaining cases: ", len(self.dicis))

    def process(self):
        self.create_output_folders()
        self.create_tensors()

    def create_tensors(self, num_processes=32):
        dicis = list(chunks(self.dicis, num_processes))
        actors = [FixedSizeMaker.remote() for _ in range(num_processes)]
        results = ray.get(
            [
                c.process.remote(
                    dicis,
                    self.spatial_size,
                    self.output_folder / ("images"),
                    self.output_folder / ("lms"),
                    src_dest_labels=self.src_dest_labels,
                )
                for c, dicis in zip(actors, dicis)
            ]
        )
        # dici = L(dici)

    def create_output_folders(self):
        maybe_makedirs(
            [
                self.output_folder / ("lms"),
                self.output_folder / ("images"),
                # self.indices_subfolder,
            ]
        )

    @property
    def output_folder(self):
        output_folder = folder_name_from_list(
            prefix="sze",
            parent_folder=self.fixed_size_folder,
            values_list=self.spatial_size,
        )
        return output_folder
        # output_folder_im = output_folder/"images"
        # output_folder_lm = output_folder/"lms"


if __name__ == "__main__":
# %%
# SECTION:-------------------- SETUP-------------------------------------------------------------------------------------- <CR> <CR>
    from fran.utils.common import *
    from fran.preprocessing.labelbounded import ImporterDataset

    P = Project(project_title="totalseg")
    P.maybe_store_projectwide_properties()

    TSL = TotalSegmenterLabels()
    src_dest_labels = list(zip(TSL.all, TSL.labelshort))
    # TSL.labelshort
    data_folder = Path(
        "/s/fran_storage/datasets/preprocessed/fixed_spacing/totalseg/spc_150_150_150"
    )
    F = FixedSizeDataGenerator(
        project=P,
        data_folder=data_folder,
        spatial_size=96,
        src_dest_labels=src_dest_labels,
    )
    F.setup(overwrite=False)
# %%
    lmf = F.output_folder / ("lms")
    list(lmf.glob("*"))
# %%
    F.process()
    output_folder = folder_name_from_list(
        prefix="sze", parent_folder=P.fixed_size_folder, values_list=[64, 64, 64]
    )
    output_folder_im = output_folder / "images"
    output_folder_lm = output_folder / "lms"
    maybe_makedirs([output_folder_im, output_folder_lm])

    images_fldr = self.data_folder / ("images")
    lms_fldr = self.data_folder / ("lms")

    lms = list(lms_fldr.glob("*"))
    imgs = list(images_fldr.glob("*"))
    pairs = [{"image": img, "lm": find_matching_fn(img, lms, False)} for img in imgs]
# %%
    tots = len(pairs)
    n_proc = 32
    spatial_size = [64, 64, 64]

# %%
    dicis = list(chunks(pairs, n_proc))
    actors = [FixedSizeMaker.remote() for _ in range(n_proc)]
# %%
    results = ray.get(
        [
            c.process.remote(
                dicis,
                spatial_size,
                output_folder_im,
                output_folder_lm,
                src_dest_labels=src_dest_labels,
            )
            for c, dicis in zip(actors, dicis)
        ]
    )
    # dici = L(dici)
# %%
    dici = tfms(dici)
# %%
    dici = L(dici)
    dici = M(dici)
# %%
    dici = E(dici)

    dici = Rz(dici)

    im, lm = dici["image"], dici["lm"]

# %%
    fn = "/s/fran_storage/datasets/preprocessed/fixed_size/litsmc/sze_64_64_64/images/totalseg_s0784.pt"
    fn2 = "/s/fran_storage/datasets/preprocessed/fixed_size/litsmc/sze_64_64_64/lms/totalseg_s0784.pt"
    trn = torch.load(fn, weights_only=False)
    t2 = torch.load(fn2, weights_only=False)
    ImageMaskViewer([trn, t2], dtypes="im")
# %%
# %%
# SECTION:-------------------- TROUBLE <CR>
    L = LoadTorchd(keys=["lm", "image"])
    M = MaskLabelRemapd(keys=["lm"], src_dest_labels=src_dest_labels, use_sitk=True)
    E = EnsureChannelFirstd(keys=["image", "lm"], channel_dim="no_channel")
    Rz = Resized(
        keys=["image", "lm"], spatial_size=spatial_size, mode=["linear", "nearest"]
    )
    S = SqueezeDimd(keys=["image", "lm"])

    Si = SaveImaged(
        keys=["image"],
        output_ext="pt",
        writer=TorchWriter,
        output_dir=output_folder_im,
        output_postfix="",
        output_dtype="float32",
        separate_folder=False,
    )
    Sl = SaveImaged(
        output_ext="pt",
        keys=["lm"],
        writer=TorchWriter,
        output_dtype="uint8",
        output_dir=output_folder_lm,
        output_postfix="",
        separate_folder=False,
    )

    # S1 = SaveImage(output_ext='pt',  output_dir=self.output_fldr_imgs, output_postfix=str(1), output_dtype='float32', writer=TorchWriter,separate_folder=False)
    tfms = Compose([L, M, E, Rz, S, Si, Sl])


# %%
