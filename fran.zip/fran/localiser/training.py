import lightning as L


if __name__ == "__main__":

    
