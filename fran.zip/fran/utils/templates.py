
mask_labels_template = {
  "1": {
    "dusting_threshold": 300, 
    "k_largest": 1
  },
  "2": {
    "dusting_threshold": 64e-3,
    "k_largest": 99
  }
}
