import ipdb
tr = ipdb.set_trace

# %%
import logging
# %%
# %%
b = resize(a,[100,100,100])
# %%
print(f("/home/ub",2,overwrite= 3 ))
# %%
if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.DEBUG)
    spam()
# %%
# %%
